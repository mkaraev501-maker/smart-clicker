package com.smartclicker

import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

class Decision(
    val action: String,      // tap, swipe, wait, back
    val x: Float, val y: Float, val x2: Float, val y2: Float,   // координаты 0..1000
    val waitS: Double,
    val reason: String,
    val memory: String
)

/** ИИ-игрок: смотрит на снимок экрана и решает, что нажать дальше. Использует твой ключ Gemini. */
object Ai {
    private class HttpErr(val code: Int, val msg: String) : RuntimeException("HTTP " + code)

    @Volatile var lastError: String = ""
    private val models = listOf("gemini-3.8-flash", "gemini-flash-latest")

    private val SYSTEM: String = """
Ты играешь в мобильную игру вместо человека. Тебе присылают скриншот экрана телефона и правила от хозяина.
Верни ОДНО следующее действие строго в JSON без пояснений вокруг:
{"action":"tap|swipe|wait|back","x":0-1000,"y":0-1000,"x2":0-1000,"y2":0-1000,"wait_s":2,"reason":"коротко почему","memory":"краткая память до 400 символов"}
Координаты x и y нормированы: 0,0 это левый верхний угол экрана, 1000,1000 правый нижний. Для tap указывай центр нужной кнопки. Для swipe задай начало (x,y) и конец (x2,y2).
action wait значит просто подождать wait_s секунд (идёт бой или анимация). action back это системная кнопка «назад»: используй, если открылось постороннее окно.
Если экран не изменился после прошлого действия, попробуй другое действие, а не повторяй то же самое.
В поле memory пиши свой план и важные факты (уровень, где проигрываешь, что уже улучшил): я верну эту память на следующем шаге.
Никогда не нажимай покупки за реальные деньги, рекламу, подписки, оценку приложения и внешние ссылки.
""".trimIndent()

    private fun encode(src: Bitmap): String {
        val w = 540
        val h = Math.max(1, src.height * w / src.width)
        val sm = Bitmap.createScaledBitmap(src, w, h, true)
        val out = ByteArrayOutputStream()
        sm.compress(Bitmap.CompressFormat.JPEG, 70, out)
        if (sm !== src) sm.recycle()
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    private fun call(key: String, model: String, b64: String, user: String, think: Boolean): String {
        val parts = JSONArray()
        parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64)))
        parts.put(JSONObject().put("text", user))
        val gc = JSONObject()
        gc.put("temperature", 0.3)
        gc.put("maxOutputTokens", 1200)
        gc.put("responseMimeType", "application/json")
        if (think) gc.put("thinkingConfig", JSONObject().put("thinkingLevel", "low"))
        val body = JSONObject()
        body.put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
        body.put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
        body.put("generationConfig", gc)

        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent")
            .openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 90000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw HttpErr(code, text.replace("\n", " ").take(200))
            val ps = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until ps.length()) {
                val p = ps.getJSONObject(i)
                if (!p.optBoolean("thought", false)) sb.append(p.optString("text", ""))
            }
            return sb.toString()
        } finally {
            conn.disconnect()
        }
    }

    private fun parse(raw: String): Decision {
        var t = raw.trim()
        if (t.startsWith("```")) t = t.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val j = JSONObject(t)
        return Decision(
            j.optString("action", "wait").lowercase(),
            j.optDouble("x", 500.0).toFloat(), j.optDouble("y", 500.0).toFloat(),
            j.optDouble("x2", 500.0).toFloat(), j.optDouble("y2", 500.0).toFloat(),
            j.optDouble("wait_s", 2.0),
            j.optString("reason", ""), j.optString("memory", "")
        )
    }

    fun decide(bmp: Bitmap, goal: String, memory: String, history: List<String>, unchanged: Boolean): Decision? {
        val key = Cfg.aiKey()
        if (key.isEmpty()) {
            lastError = "нет ключа"
            return null
        }
        val b64 = encode(bmp)
        val user = "Правила от хозяина:\n" + goal +
            "\n\nТвоя память: " + (if (memory.isEmpty()) "пока пусто" else memory) +
            "\nПоследние действия: " + (if (history.isEmpty()) "нет" else history.joinToString(" | ")) +
            "\nЭкран после прошлого действия " + (if (unchanged) "НЕ изменился" else "изменился") +
            ".\nВерни следующее действие."
        for (model in models) {
            var think = true
            var attempt = 0
            while (attempt < 3) {
                try {
                    val d = parse(call(key, model, b64, user, think))
                    lastError = ""
                    return d
                } catch (e: HttpErr) {
                    lastError = "HTTP " + e.code + ": " + e.msg
                    if (e.code == 400 && think) {
                        think = false
                        continue
                    }
                    if (e.code == 401 || e.code == 403) return null
                    if (e.code == 400 || e.code == 404) break
                    attempt++
                    Thread.sleep(8000L * attempt)
                } catch (e: Exception) {
                    lastError = e.message ?: e.toString()
                    attempt++
                    Thread.sleep(4000L)
                }
            }
        }
        return null
    }
}
