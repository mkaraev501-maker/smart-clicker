package com.smartclicker

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

class Gray(val w: Int, val h: Int, val d: IntArray)

/** Поиск маленькой картинки (кнопки) внутри снимка экрана. Всё считается на телефоне. */
object Matcher {
    const val SCALE = 4

    /** Уменьшаем в 4 раза и переводим в оттенки серого, чтобы было быстро. */
    fun prepare(src: Bitmap): Gray {
        val w = Math.max(1, src.width / SCALE)
        val h = Math.max(1, src.height / SCALE)
        val sm = Bitmap.createScaledBitmap(src, w, h, true)
        val px = IntArray(w * h)
        sm.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            px[i] = (r * 30 + g * 59 + b * 11) / 100
        }
        if (sm !== src) sm.recycle()
        return Gray(w, h, px)
    }

    fun loadTemplate(f: File): Gray? {
        if (!f.exists()) return null
        val bmp = BitmapFactory.decodeFile(f.absolutePath) ?: return null
        val g = prepare(bmp)
        bmp.recycle()
        return g
    }

    /** Возвращает центр найденной кнопки в уменьшенных координатах или null. */
    fun find(scr: Gray, t: Gray, th: Double): IntArray? {
        if (t.w > scr.w || t.h > scr.h) return null
        val maxMean = (1.0 - th) * 255.0
        val maxSad = (maxMean * t.w * t.h).toLong()
        var limit = maxSad
        var bx = -1
        var by = -1
        for (y in 0..(scr.h - t.h)) {
            for (x in 0..(scr.w - t.w)) {
                var sad = 0L
                var ty = 0
                while (ty < t.h && sad <= limit) {
                    val so = (y + ty) * scr.w + x
                    val to = ty * t.w
                    var tx = 0
                    while (tx < t.w) {
                        val d = scr.d[so + tx] - t.d[to + tx]
                        sad += if (d < 0) -d else d
                        tx++
                    }
                    ty++
                }
                if (ty == t.h && sad <= limit) {
                    limit = sad
                    bx = x
                    by = y
                }
            }
        }
        if (bx < 0) return null
        return intArrayOf(bx + t.w / 2, by + t.h / 2)
    }

    /** Почти одинаковые кадры? Нужно, чтобы понять, что нажатие ничего не изменило. */
    fun similar(a: Gray, b: Gray): Boolean {
        if (a.w != b.w || a.h != b.h) return false
        var sum = 0L
        var n = 0
        var i = 0
        while (i < a.d.size) {
            val d = a.d[i] - b.d[i]
            sum += if (d < 0) -d else d
            n++
            i += 7
        }
        return n > 0 && sum.toDouble() / n < 3.0
    }
}
