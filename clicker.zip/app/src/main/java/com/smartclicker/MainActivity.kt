package com.smartclicker

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var statusView: TextView
    private lateinit var statsView: TextView
    private lateinit var intervalInput: EditText
    private lateinit var stopInput: EditText
    private lateinit var rulesBox: LinearLayout
    private lateinit var aiKeyInput: EditText
    private lateinit var goalInput: EditText
    private lateinit var aiStepInput: EditText
    private lateinit var aiBtn: Button
    private lateinit var aiLogView: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }
    private var dp = 1f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Rules.init(this)
        Cfg.init(this)
        dp = resources.displayMetrics.density
        val pad = (16 * dp).toInt()

        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.setPadding(pad, (32 * dp).toInt(), pad, pad)

        t.addView(label("Умный кликер", 24f))
        t.addView(label("Он не нажимает точку по таймеру: делает снимок экрана, ищет на нём кнопки, которые ты ему показал, и нажимает только когда они есть. Простые кнопки он нажимает сам на телефоне. Интернет нужен только для ИИ-игрока.", 13f))

        t.addView(space())
        t.addView(label("1. Включи службу", 17f))
        t.addView(label("Если переключатель серый: «Сведения о приложении» → три точки вверху справа → «Разрешить ограниченные настройки». Потом «Специальные возможности» → «Умный кликер» → включить.", 13f))
        t.addView(button("Сведения о приложении") {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            i.data = Uri.parse("package:" + packageName)
            startActivity(i)
        })
        t.addView(button("Открыть «Специальные возможности»") {
            try {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } catch (e: Exception) {
                toast("Открой настройки вручную")
            }
        })
        statusView = label("", 15f)
        t.addView(statusView)
        t.addView(button("Показать плавающую панель") {
            val s = ClickerService.instance
            if (s == null) toast("Сначала включи службу")
            else s.showPanel()
        })

        t.addView(space())
        t.addView(label("2. Покажи кнопки", 17f))
        t.addView(label("Открой игру. На панели нажми «+ Кнопка»: появится снимок экрана. Нажми левый верхний, потом правый нижний угол нужной кнопки (например «Начать бой», «Забрать награду», «Продолжить»). Так добавь все кнопки. Правила проверяются сверху вниз: самые важные поднимай стрелкой вверх. Потом нажми «▶ Старт».", 13f))

        t.addView(space())
        t.addView(label("Мои кнопки", 17f))
        rulesBox = LinearLayout(this)
        rulesBox.orientation = LinearLayout.VERTICAL
        t.addView(rulesBox)

        t.addView(space())
        t.addView(label("3. ИИ-игрок (играет как человек)", 17f))
        t.addView(label("Когда ни одна из твоих кнопок не подошла, ИИ смотрит на экран и сам решает: нажать, провести пальцем, подождать или вернуться. Проиграл бой, значит, идёт качать корабли и башни, потом возвращается. Он помнит свой план между шагами. Нужен твой бесплатный ключ Gemini (aistudio.google.com/apikey). Внимание: пока ИИ включён, уменьшенные снимки экрана отправляются в Google, поэтому держи на экране только игру. Решение занимает несколько секунд, а у бесплатного ключа есть дневной лимит.", 13f))
        aiKeyInput = EditText(this)
        aiKeyInput.hint = "Ключ Gemini API"
        aiKeyInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        aiKeyInput.setSingleLine()
        aiKeyInput.setText(Cfg.aiKey())
        t.addView(aiKeyInput)
        t.addView(label("Что делать и чего нельзя (можно править):", 13f))
        goalInput = EditText(this)
        goalInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        goalInput.minLines = 6
        goalInput.gravity = Gravity.TOP
        goalInput.setText(Cfg.goal())
        t.addView(goalInput)
        aiStepInput = numberInput("Секунд между решениями ИИ", (Cfg.stepMs() / 1000L).toString())
        t.addView(aiStepInput)
        aiBtn = button("") { toggleAi() }
        t.addView(aiBtn)
        aiLogView = label("", 12f)
        t.addView(aiLogView)

        t.addView(space())
        t.addView(label("Настройки", 17f))
        intervalInput = numberInput("Как часто смотреть на экран, мс", Cfg.intervalMs().toString())
        t.addView(intervalInput)
        stopInput = numberInput("Выключиться через, минут (0 = не выключать)", Cfg.autoStopMin().toString())
        t.addView(stopInput)
        t.addView(button("Сохранить настройки") {
            val iv = intervalInput.text.toString().trim().toLongOrNull() ?: 800L
            val st = stopInput.text.toString().trim().toIntOrNull() ?: 30
            Cfg.save(iv, st)
            toast("Сохранено")
        })

        t.addView(space())
        statsView = label("", 14f)
        t.addView(statsView)
        t.addView(label("Не добавляй рекламные баннеры и не используй кликер в рейтинговых режимах: игра может заблокировать аккаунт, а клики по рекламе нарушают правила рекламных сетей.", 12f))

        val sv = ScrollView(this)
        sv.addView(t)
        setContentView(sv)
        renderRules()
    }

    private fun label(s: String, size: Float): TextView {
        val v = TextView(this)
        v.text = s
        v.textSize = size
        v.setPadding(0, (4 * dp).toInt(), 0, (4 * dp).toInt())
        return v
    }

    private fun space(): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (14 * dp).toInt())
        return v
    }

    private fun button(s: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.setAllCaps(false)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun numberInput(hint: String, def: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(def)
        e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        e.setSingleLine()
        return e
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains(packageName)
    }

    // ---------- список правил ----------

    private fun renderRules() {
        rulesBox.removeAllViews()
        val list = Rules.list()
        if (list.isEmpty()) {
            rulesBox.addView(label("Пока ни одной кнопки. Открой игру и нажми «+ Кнопка» на плавающей панели.", 13f))
        }
        for (r in list) {
            val top = LinearLayout(this)
            top.orientation = LinearLayout.HORIZONTAL
            top.gravity = Gravity.CENTER_VERTICAL
            val img = ImageView(this)
            img.scaleType = ImageView.ScaleType.FIT_CENTER
            val bmp = BitmapFactory.decodeFile(Rules.file(r.id).absolutePath)
            if (bmp != null) img.setImageBitmap(bmp)
            top.addView(img, LinearLayout.LayoutParams((90 * dp).toInt(), (60 * dp).toInt()))
            val info = (if (r.enabled) r.name else r.name + " (выключено)") +
                "\nточность " + (r.th * 100).toInt() + "%, пауза " + (r.cooldownMs / 1000.0) + " с"
            top.addView(label(info, 13f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            rulesBox.addView(top)

            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            row.addView(button("↑") {
                Rules.move(r.id, -1)
                renderRules()
            }, lp)
            row.addView(button("↓") {
                Rules.move(r.id, 1)
                renderRules()
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(button("Правка") { editRule(r) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.5f))
            row.addView(button(if (r.enabled) "Выкл" else "Вкл") {
                r.enabled = !r.enabled
                Rules.changed()
                renderRules()
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.2f))
            row.addView(button("Удалить") {
                Rules.remove(r.id)
                renderRules()
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.5f))
            rulesBox.addView(row)
        }
    }

    private fun editRule(r: Rule) {
        val lay = LinearLayout(this)
        lay.orientation = LinearLayout.VERTICAL
        val p = (16 * dp).toInt()
        lay.setPadding(p, p, p, 0)
        val nameE = EditText(this)
        nameE.hint = "Название"
        nameE.setText(r.name)
        val cdE = numberInput("Пауза после нажатия, секунд", (r.cooldownMs / 1000.0).toString())
        val thE = numberInput("Точность совпадения, % (70-99)", (r.th * 100).toInt().toString())
        lay.addView(nameE)
        lay.addView(cdE)
        lay.addView(thE)
        lay.addView(label("Если кнопка не находится, снизь точность. Если нажимает лишнее, подними.", 12f))
        AlertDialog.Builder(this)
            .setTitle("Настройки кнопки")
            .setView(lay)
            .setPositiveButton("Сохранить") { _, _ ->
                val n = nameE.text.toString().trim()
                if (n.isNotEmpty()) r.name = n
                val cd = cdE.text.toString().replace(',', '.').toDoubleOrNull() ?: 1.5
                r.cooldownMs = (cd * 1000.0).toLong().coerceIn(0L, 60000L)
                val th = thE.text.toString().trim().toIntOrNull() ?: 90
                r.th = th.coerceIn(70, 99) / 100.0
                Rules.changed()
                renderRules()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun toggleAi() {
        val step = (aiStepInput.text.toString().toLongOrNull() ?: 4L) * 1000L
        if (Cfg.aiOn()) {
            Cfg.saveAi(aiKeyInput.text.toString().trim(), false, goalInput.text.toString(), step)
            toast("ИИ выключен")
            return
        }
        val key = aiKeyInput.text.toString().trim()
        if (key.isEmpty()) {
            toast("Сначала вставь ключ Gemini")
            return
        }
        Cfg.saveAi(key, true, goalInput.text.toString(), step)
        toast("ИИ включён. Запусти кликер кнопкой ▶ на панели")
    }

    // ---------- обновление ----------

    private fun refresh() {
        statusView.text = if (serviceOn()) "Служба: ВКЛЮЧЕНА" else "Служба: ВЫКЛЮЧЕНА. Сделай шаг 1."
        statsView.text = "Нажато раз: " + Cfg.clicks + ". Последнее: " + Cfg.last
        aiBtn.text = if (Cfg.aiOn()) "ИИ-игрок: ВКЛЮЧЁН (нажми, чтобы выключить)" else "Включить ИИ-игрока"
        aiLogView.text = if (Cfg.aiLog.isEmpty()) "Журнал решений ИИ пуст" else "Решения ИИ:\n" + Cfg.aiLog
    }

    override fun onResume() {
        super.onResume()
        renderRules()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }
}
