package com.smartclicker

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/** Одно правило: «если на экране есть вот эта кнопка, нажми её». */
class Rule(
    val id: String,
    var name: String,
    var th: Double,          // насколько точно должно совпасть, 0.80-0.99
    var cooldownMs: Long,    // пауза после клика
    var enabled: Boolean
)

object Rules {
    private var prefs: SharedPreferences? = null
    private var dir: File? = null
    private val items = ArrayList<Rule>()

    @Synchronized
    fun init(c: Context) {
        if (prefs != null) return
        val app = c.applicationContext
        prefs = app.getSharedPreferences("rules", Context.MODE_PRIVATE)
        val d = File(app.filesDir, "rules")
        d.mkdirs()
        dir = d
        load()
    }

    private fun load() {
        items.clear()
        try {
            val a = JSONArray(prefs?.getString("items", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                items.add(
                    Rule(
                        o.getString("id"), o.getString("name"),
                        o.optDouble("th", 0.9), o.optLong("cd", 1500L), o.optBoolean("on", true)
                    )
                )
            }
        } catch (e: Exception) {
            items.clear()
        }
    }

    private fun save() {
        val a = JSONArray()
        for (r in items) {
            val o = JSONObject()
            o.put("id", r.id)
            o.put("name", r.name)
            o.put("th", r.th)
            o.put("cd", r.cooldownMs)
            o.put("on", r.enabled)
            a.put(o)
        }
        prefs?.edit()?.putString("items", a.toString())?.apply()
    }

    @Synchronized
    fun list(): List<Rule> = ArrayList<Rule>(items)

    fun file(id: String): File = File(dir, id + ".png")

    @Synchronized
    fun add(name: String, bmp: Bitmap): Rule {
        val id = System.currentTimeMillis().toString()
        FileOutputStream(file(id)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val r = Rule(id, name, 0.9, 1500L, true)
        items.add(r)
        save()
        return r
    }

    @Synchronized
    fun remove(id: String) {
        val it = items.iterator()
        while (it.hasNext()) {
            if (it.next().id == id) it.remove()
        }
        file(id).delete()
        save()
    }

    @Synchronized
    fun move(id: String, delta: Int) {
        val i = items.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j < 0 || j >= items.size) return
        val r = items.removeAt(i)
        items.add(j, r)
        save()
    }

    @Synchronized
    fun changed() = save()
}

/** Общие настройки и счётчики. */
object Cfg {
    private var prefs: SharedPreferences? = null
    @Volatile var clicks: Int = 0
    @Volatile var last: String = "ещё не нажимал"

    fun init(c: Context) {
        if (prefs == null) prefs = c.applicationContext.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    }

    fun intervalMs(): Long = prefs?.getLong("interval", 800L) ?: 800L
    fun autoStopMin(): Int = prefs?.getInt("autostop", 30) ?: 30

    fun save(intervalMs: Long, autoStopMin: Int) {
        prefs?.edit()?.putLong("interval", intervalMs.coerceIn(400L, 10000L))?.putInt("autostop", autoStopMin.coerceIn(0, 600))?.apply()
    }

    // ---------- ИИ-игрок ----------

    val DEFAULT_GOAL: String = """
Игра: Mega Tower 2: Starship Voyage. Космическая стратегия: флот кораблей, оборонительные башни, технологии, галактики, артефакты, шахты, гильдии.
Задача: проходить уровни и галактики как можно дальше.
Как играть:
- Если на экране победа, награда или «продолжить»: забери награду и иди дальше.
- Если идёт бой, обычно достаточно подождать (action wait).
- Если проиграл бой или видно, что враги сильнее: открой меню улучшений и потрать ресурсы на корабли, башни и технологии, открой новое (корабли, башни, галактики), потом вернись в бой.
- Собирай бесплатные награды, ежедневные задания, шахту, бесплатное колесо.
- Запоминай в memory, на каком уровне проигрываешь и что уже прокачал.
Запрещено: покупки за реальные деньги, пополнение, подписки, просмотр и нажатие рекламы, оценка приложения, внешние ссылки, выход из игры.
""".trimIndent()

    @Volatile var aiLog: String = ""

    fun aiKey(): String = prefs?.getString("aikey", "") ?: ""
    fun aiOn(): Boolean = prefs?.getBoolean("aion", false) ?: false
    fun goal(): String = prefs?.getString("goal", null) ?: DEFAULT_GOAL
    fun stepMs(): Long = prefs?.getLong("stepms", 4000L) ?: 4000L

    fun saveAi(key: String, on: Boolean, goalText: String, stepMs: Long) {
        prefs?.edit()
            ?.putString("aikey", key)
            ?.putBoolean("aion", on)
            ?.putString("goal", goalText)
            ?.putLong("stepms", stepMs.coerceIn(2000L, 60000L))
            ?.apply()
    }

    fun addLog(s: String) {
        val lines = (s + "\n" + aiLog).split("\n").filter { it.isNotBlank() }.take(8)
        aiLog = lines.joinToString("\n")
    }
}
