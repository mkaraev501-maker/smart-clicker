package com.smartclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Умный кликер: делает снимок экрана, ищет на нём кнопки, которые ты показал, и нажимает.
 * Правила проверяются сверху вниз, нажимается первое найденное.
 */
class ClickerService : AccessibilityService() {
    companion object {
        @Volatile var instance: ClickerService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var panel: LinearLayout? = null
    private var runBtn: Button? = null
    private var learnView: View? = null
    private var learnBmp: Bitmap? = null
    @Volatile private var running = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Rules.init(this)
        Cfg.init(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        main.post { showPanel() }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        running = false
        main.post {
            closeLearn()
            hidePanel()
        }
        instance = null
        return super.onUnbind(intent)
    }

    private fun toast(t: String) {
        main.post { Toast.makeText(applicationContext, t, Toast.LENGTH_SHORT).show() }
    }

    // ---------- плавающая панель ----------

    private fun smallButton(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.textSize = 12f
        b.setAllCaps(false)
        b.minWidth = 0
        b.minimumWidth = 0
        b.minHeight = 0
        b.minimumHeight = 0
        b.setOnClickListener { onClick() }
        return b
    }

    fun showPanel() {
        if (panel != null) return
        val dp = resources.displayMetrics.density
        val ll = LinearLayout(this)
        ll.orientation = LinearLayout.HORIZONTAL
        ll.setBackgroundColor(0xCC202124.toInt())
        val p = (4 * dp).toInt()
        ll.setPadding(p, p, p, p)
        val run = smallButton("▶ Старт") { toggleRun() }
        runBtn = run
        ll.addView(run)
        ll.addView(smallButton("+ Кнопка") { startLearn() })
        ll.addView(smallButton("Скрыть") { hidePanel() })
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = (96 * dp).toInt()
        try {
            wm?.addView(ll, lp)
            panel = ll
        } catch (e: Exception) {
            toast("Не удалось показать панель")
        }
    }

    fun hidePanel() {
        val v = panel
        if (v != null) {
            try {
                wm?.removeView(v)
            } catch (e: Exception) {
                // уже убрана
            }
        }
        panel = null
        runBtn = null
    }

    private fun updatePanel() {
        runBtn?.text = if (running) "■ Стоп" else "▶ Старт"
    }

    // ---------- обучение: показать кнопку ----------

    private fun startLearn() {
        if (running) {
            toast("Сначала останови кликер")
            return
        }
        if (learnView != null) return
        panel?.visibility = View.INVISIBLE
        main.postDelayed({
            val t = Thread {
                val bmp = grab()
                main.post {
                    panel?.visibility = View.VISIBLE
                    if (bmp == null) toast("Не получилось сделать снимок экрана") else showLearn(bmp)
                }
            }
            t.isDaemon = true
            t.start()
        }, 400)
    }

    private fun showLearn(bmp: Bitmap) {
        val dp = resources.displayMetrics.density
        val root = FrameLayout(this)
        val iv = ImageView(this)
        iv.setImageBitmap(bmp)
        iv.scaleType = ImageView.ScaleType.FIT_XY
        root.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val hint = TextView(this)
        hint.text = "Нажми на ЛЕВЫЙ ВЕРХНИЙ угол кнопки"
        hint.setBackgroundColor(0xCC000000.toInt())
        hint.setTextColor(0xFFFFFFFF.toInt())
        hint.textSize = 16f
        val hp = (10 * dp).toInt()
        hint.setPadding(hp, hp * 3, hp, hp)
        root.addView(hint, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        val cancel = Button(this)
        cancel.text = "Отмена"
        cancel.setOnClickListener { closeLearn() }
        root.addView(
            cancel,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        )

        var x1 = -1f
        var y1 = -1f
        iv.setOnTouchListener { v, ev ->
            if (ev.action == MotionEvent.ACTION_UP) {
                val fx = ev.x * bmp.width / v.width
                val fy = ev.y * bmp.height / v.height
                if (x1 < 0f) {
                    x1 = fx
                    y1 = fy
                    hint.text = "Теперь нажми на ПРАВЫЙ НИЖНИЙ угол кнопки"
                } else {
                    val left = Math.max(0, Math.min(x1, fx).toInt())
                    val top = Math.max(0, Math.min(y1, fy).toInt())
                    val w = Math.abs(fx - x1).toInt()
                    val h = Math.abs(fy - y1).toInt()
                    if (w < 40 || h < 40) {
                        toast("Область слишком маленькая, выбери кнопку крупнее")
                        x1 = -1f
                        hint.text = "Нажми на ЛЕВЫЙ ВЕРХНИЙ угол кнопки"
                    } else {
                        val cw = Math.min(w, bmp.width - left)
                        val ch = Math.min(h, bmp.height - top)
                        val crop = Bitmap.createBitmap(bmp, left, top, cw, ch)
                        val rule = Rules.add("Кнопка " + (Rules.list().size + 1), crop)
                        crop.recycle()
                        closeLearn()
                        toast("Сохранено: " + rule.name)
                    }
                }
            }
            true
        }

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm?.addView(root, lp)
            learnView = root
            learnBmp = bmp
        } catch (e: Exception) {
            toast("Не удалось показать снимок")
        }
    }

    private fun closeLearn() {
        val v = learnView
        if (v != null) {
            try {
                wm?.removeView(v)
            } catch (e: Exception) {
                // уже убран
            }
        }
        learnView = null
        learnBmp = null
    }

    // ---------- движок ----------

    private fun toggleRun() {
        if (running) stopEngine() else startEngine()
    }

    fun startEngine() {
        if (running) return
        if (Rules.list().none { it.enabled }) {
            toast("Нет правил. Нажми «+ Кнопка» и покажи кнопку")
            return
        }
        running = true
        updatePanel()
        val t = Thread { engine() }
        t.isDaemon = true
        t.start()
    }

    fun stopEngine() {
        running = false
        main.post { updatePanel() }
    }

    private fun nap(ms: Long) {
        var left = ms
        while (left > 0L && running) {
            Thread.sleep(Math.min(left, 200L))
            left -= 200L
        }
    }

    private var memory = ""
    private val history = ArrayList<String>()
    private var prevGray: Gray? = null

    private fun engine() {
        val cache = HashMap<String, Gray>()
        val started = System.currentTimeMillis()
        memory = ""
        history.clear()
        prevGray = null
        while (running) {
            val limit = Cfg.autoStopMin()
            if (limit > 0 && System.currentTimeMillis() - started > limit * 60000L) {
                toast("Время вышло, кликер остановлен")
                break
            }
            var usedAi = false
            val bmp = grab()
            if (bmp != null) {
                val scr = Matcher.prepare(bmp)
                var clicked = false
                for (r in Rules.list()) {
                    if (!running) break
                    if (!r.enabled) continue
                    val tpl = cache[r.id] ?: Matcher.loadTemplate(Rules.file(r.id)) ?: continue
                    cache[r.id] = tpl
                    val hit = Matcher.find(scr, tpl, r.th)
                    if (hit != null) {
                        tap((hit[0] * Matcher.SCALE).toFloat(), (hit[1] * Matcher.SCALE).toFloat())
                        Cfg.clicks = Cfg.clicks + 1
                        Cfg.last = r.name
                        clicked = true
                        nap(r.cooldownMs)
                        break
                    }
                }
                if (!clicked && running && Cfg.aiOn() && Cfg.aiKey().isNotEmpty()) {
                    usedAi = true
                    aiStep(bmp, scr)
                }
                prevGray = scr
                bmp.recycle()
            }
            nap(if (usedAi) Cfg.stepMs() else Cfg.intervalMs())
        }
        running = false
        main.post { updatePanel() }
    }

    /** ИИ смотрит на экран и решает, что делать: нажать, провести пальцем, подождать или вернуться. */
    private fun aiStep(bmp: Bitmap, scr: Gray) {
        val prev = prevGray
        val unchanged = prev != null && Matcher.similar(prev, scr)
        val d = Ai.decide(bmp, Cfg.goal(), memory, history, unchanged)
        if (d == null) {
            Cfg.last = "ИИ: ошибка " + Ai.lastError.take(80)
            Cfg.addLog("Ошибка ИИ: " + Ai.lastError.take(100))
            return
        }
        if (d.memory.isNotEmpty()) memory = d.memory.take(600)
        val low = d.reason.lowercase()
        val risky = listOf("реальн", "real money", "реклам", "advert", "подписк", "subscri", "purchase").any { low.contains(it) }
        if (risky) {
            Cfg.addLog("Пропустил рискованное: " + d.reason.take(80))
            return
        }
        val w = bmp.width.toFloat()
        val h = bmp.height.toFloat()
        var desc = d.action
        when (d.action) {
            "tap" -> {
                tap(d.x / 1000f * w, d.y / 1000f * h)
                Cfg.clicks = Cfg.clicks + 1
                desc = "нажал (" + d.x.toInt() + "," + d.y.toInt() + ")"
            }
            "swipe" -> {
                swipe(d.x / 1000f * w, d.y / 1000f * h, d.x2 / 1000f * w, d.y2 / 1000f * h)
                desc = "провёл (" + d.x.toInt() + "," + d.y.toInt() + ")->(" + d.x2.toInt() + "," + d.y2.toInt() + ")"
            }
            "back" -> {
                performGlobalAction(GLOBAL_ACTION_BACK)
                desc = "назад"
            }
            else -> {
                nap((d.waitS.coerceIn(1.0, 20.0) * 1000.0).toLong())
                desc = "ждал"
            }
        }
        history.add(desc + ": " + d.reason.take(60))
        if (history.size > 6) history.removeAt(0)
        Cfg.last = "ИИ: " + d.reason.take(80)
        Cfg.addLog(desc + ". " + d.reason.take(90))
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        main.post {
            val p = Path()
            p.moveTo(x1, y1)
            p.lineTo(x2, y2)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(p, 0L, 350L))
                .build()
            dispatchGesture(g, null, null)
        }
    }

    private fun tap(x: Float, y: Float) {
        main.post {
            val p = Path()
            p.moveTo(x, y)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(p, 0L, 50L))
                .build()
            dispatchGesture(g, null, null)
        }
    }

    /** Снимок экрана. Работает на Android 11 и новее. */
    private fun grab(): Bitmap? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1)
        var out: Bitmap? = null
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY, mainExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                        try {
                            val hb = result.hardwareBuffer
                            val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                            out = hw?.copy(Bitmap.Config.ARGB_8888, false)
                            hw?.recycle()
                            hb.close()
                        } catch (e: Exception) {
                            // снимок не получился
                        }
                        latch.countDown()
                    }

                    override fun onFailure(errorCode: Int) {
                        latch.countDown()
                    }
                }
            )
        } catch (e: Exception) {
            return null
        }
        latch.await(3, TimeUnit.SECONDS)
        return out
    }
}
